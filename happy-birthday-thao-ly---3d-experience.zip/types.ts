
// Add import for THREE to provide the namespace for types
import * as THREE from 'three';

export enum AppMode {
  TREE = 'TREE',
  SCATTER = 'SCATTER',
  FOCUS = 'FOCUS',
  DATE = 'DATE'
}

export interface HandData {
  detected: boolean;
  x: number;
  y: number;
  isHeart: boolean;
}

export interface ParticleType {
  mesh: THREE.Object3D;
  type: string;
  isDust: boolean;
  posTree: THREE.Vector3;
  posScatter: THREE.Vector3;
  posDate: THREE.Vector3;
  baseScale: number;
  spinSpeed: THREE.Vector3;
}
