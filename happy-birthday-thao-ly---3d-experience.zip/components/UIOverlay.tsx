
import React from 'react';
import { AppMode } from '../types';

interface UIOverlayProps {
  visible: boolean;
  onUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  mode: AppMode;
  loading: boolean;
  isMobile: boolean;
}

const UIOverlay: React.FC<UIOverlayProps> = ({ visible, onUpload, mode, loading, isMobile }) => {
  return (
    <>
      {/* Loading Screen */}
      <div 
        className={`absolute inset-0 z-[100] flex flex-col items-center justify-center bg-black transition-opacity duration-1000 pointer-events-none ${
          loading ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="w-10 h-10 border-2 border-yellow-500/20 border-t-yellow-500 rounded-full animate-spin mb-4" />
        <span className="text-yellow-500 font-cinzel tracking-[6px] text-xs uppercase">Initialising Celebration</span>
      </div>

      {/* Main UI */}
      <div 
        className={`absolute inset-0 z-10 pointer-events-none flex flex-col items-center pt-20 ui-transition ${
          visible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
        }`}
      >
        {/* Title */}
        <div className="text-center flex flex-col items-center">
          <h1 className="text-3xl md:text-6xl font-cinzel text-transparent bg-clip-text bg-gradient-to-b from-white via-yellow-200 to-yellow-500 drop-shadow-[0_0_30px_rgba(253,224,71,0.4)] tracking-[8px] mb-2 px-4 uppercase">
            Happy Birthday
          </h1>
          <h2 className="text-6xl md:text-9xl font-playfair italic text-yellow-100 tracking-[6px] opacity-90 mb-12 drop-shadow-2xl">
            Thao Ly
          </h2>
        </div>

        {/* Buttons - Restored & Interactive */}
        <div className="mt-8 flex flex-col items-center gap-4 pointer-events-auto">
          <label className="group relative overflow-hidden bg-black/40 backdrop-blur-md border border-yellow-500/30 px-12 py-4 cursor-pointer transition-all hover:bg-yellow-500 hover:text-black hover:shadow-[0_0_40px_rgba(234,179,8,0.6)]">
            <span className="text-xs tracking-[5px] font-inter uppercase transition-colors">Add Memories</span>
            <input 
              type="file" 
              multiple 
              accept="image/*" 
              className="hidden" 
              onChange={onUpload}
            />
          </label>
          
          {!isMobile && (
            <div className="text-[9px] text-yellow-500/40 tracking-widest uppercase mt-4">
              Press 'H' to hide controls
            </div>
          )}
          
          {isMobile && (
            <div className="text-[9px] text-yellow-500/40 tracking-widest uppercase mt-4 px-6 text-center">
              Add photos to begin the gesture experience
            </div>
          )}
        </div>

        {/* Current Mode Indicator */}
        <div className="absolute top-8 right-8 text-yellow-500/60 text-[10px] tracking-[3px] uppercase font-cinzel border-r border-yellow-500/20 pr-4 py-1">
          {mode} Mode
        </div>
      </div>

      {/* Aesthetic Border Accent */}
      <div className="absolute inset-0 pointer-events-none border-[1px] border-yellow-500/10 m-4 z-0" />
    </>
  );
};

export default UIOverlay;
