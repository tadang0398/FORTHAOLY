
export const CONFIG = {
  colors: {
    bg: 0x000000,
    champagneGold: 0xffd966,
    deepGreen: 0x03180a,
    accentRed: 0x990000,
    softWhite: 0xfffcf0
  },
  particles: {
    count: 1200,
    dustCount: 1800,
    treeHeight: 24,
    treeRadius: 8
  },
  camera: {
    z: 50
  }
};
